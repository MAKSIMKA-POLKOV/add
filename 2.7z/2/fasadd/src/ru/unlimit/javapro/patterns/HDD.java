package ru.unlimit.javapro.patterns;

class HDD {
    void copyFromDVD(DVDRom dvd) {
        if (dvd.getDataStatus()) {
            System.out.println("Происходит копирование данных с диска");
        } else {
            System.out.println("Вставьте диск с данными");
        }
    }

    void getDataFromDVD(DVDRom dvd) {
        if (dvd.getDataStatus()) {
            System.out.println("Получение данных с диска");
        } else {
            System.out.println("Диск пуст");
        }
    }
}
