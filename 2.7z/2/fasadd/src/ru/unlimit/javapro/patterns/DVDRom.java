package ru.unlimit.javapro.patterns;

class DVDRom{
    private boolean data = false;
    public boolean getDataStatus(){
        return data;
    }
    void load(){
        data = true;
    }
    void unload(){
        data = false;
    }
}