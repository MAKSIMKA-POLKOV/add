package ru.unlimit.javapro.patterns;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

        Computer computer = new Computer();
        computer.copy();
    }
}
