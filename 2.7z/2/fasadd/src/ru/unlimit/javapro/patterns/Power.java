package ru.unlimit.javapro.patterns;

class Power {
    void on () {
        System.out.println("Включение питания");
    }
    void off(){
        System.out.println("Выключение питания");
    }
}