import java.util.HashMap;
import java.util.List;
import java.util.Map;

class DoctorSchedule {
    private Map<Doctor, List<String>> schedule;

    public DoctorSchedule() {
        schedule = new HashMap<>();
    }

    public void addDoctorSchedule(Doctor doctor, List<String> availableTimes) {
        schedule.put(doctor, availableTimes);
    }

    public Map<Doctor, List<String>> getDoctorSchedule() {
        return schedule;
    }

    public boolean isTimeAvailable(Doctor doctor, String time) {
        if (schedule.containsKey(doctor)) {
            List<String> availableTimes = schedule.get(doctor);
            return availableTimes.contains(time);
        } else {
            return false;
        }
    }

    public void scheduleAppointment(Doctor doctor, String time) {
        if (schedule.containsKey(doctor)) {
            List<String> availableTimes = schedule.get(doctor);
            availableTimes.remove(time);
            schedule.put(doctor, availableTimes);
        }
    }
}
