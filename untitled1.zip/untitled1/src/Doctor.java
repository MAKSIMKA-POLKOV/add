class Doctor {
    private String name;
    private String office;

    private String speciality;

    public Doctor(String name, String office, String speciality) {
        this.name = name;
        this.office = office;
        this.speciality = speciality;
    }

    public String getName() {
        return name;
    }

    public String getOffice() {
        return office;
    }

    public String getSpeciality() {
        return speciality;
    }
}
