import java.util.*;

public class DoctorAppointmentSystem {
    public static void main(String[] args) {
        Doctor doctor1 = new Doctor("Иванов Г.В", "Кабинет 101", "Терапевт");
        Doctor doctor2 = new Doctor("Петров В.А", "Кабинет 202", "Хирург");
        Doctor doctor3 = new Doctor("Шамаева О.В", "Кабинет 308", "Офтальмолог");
        Doctor doctor4 = new Doctor("Маркова Г.В", "Кабинет 210", "Оториноларинголог");
        Doctor doctor5 = new Doctor("Лухин Ш.Г", "Кабинет 104", "Уролог" );
        Doctor doctor6 = new Doctor("Амаев В.В", "Кабинет 314", "Акушер-гинеколог");

        DoctorSchedule doctorSchedule = new DoctorSchedule();
        doctorSchedule.addDoctorSchedule(doctor1, new ArrayList<>(List.of("09:00", "14:00", "17:00")));
        doctorSchedule.addDoctorSchedule(doctor2, new ArrayList<>(List.of("08:00", "12:00", "16:00")));
        doctorSchedule.addDoctorSchedule(doctor3, new ArrayList<>(List.of("10:30", "12:45", "16:00")));
        doctorSchedule.addDoctorSchedule(doctor4, new ArrayList<>(List.of("10:00", "16:00", "20:00")));
        doctorSchedule.addDoctorSchedule(doctor5, new ArrayList<>(List.of("08:30", "11:45", "14:00")));
        doctorSchedule.addDoctorSchedule(doctor6, new ArrayList<>(List.of("10:00", "12:00", "14:00")));

        Map<String, String> appointments = new HashMap<>();

        Scanner scanner = new Scanner(System.in);
        int choice = 0;

        do {
            System.out.println("Выберите действие:");
            System.out.println("1. Создать пользователя для записи на прием");
            System.out.println("2. Пользователи, которые записаны на прием");
            System.out.println("3. Закрыть");

            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.println("Введите ФИО и код пользователя:");
                    String userName = scanner.nextLine();

                    System.out.println("Выберите доктора:");
                    for (Doctor doctor : doctorSchedule.getDoctorSchedule().keySet()) {
                        System.out.println(doctor.getName() + ", " + doctor.getOffice() + ", " + doctor.getSpeciality());
                    }
                    String selectedDoctorName = scanner.nextLine();
                    Doctor selectedDoctor = null;
                    for (Doctor doctor : doctorSchedule.getDoctorSchedule().keySet()) {
                        if (doctor.getName().equals(selectedDoctorName)) {
                            selectedDoctor = doctor;
                            break;
                        }
                    }
                    if (selectedDoctor == null) {
                        System.out.println("Доктор не найден.");
                        break;
                    }

                    System.out.println("Свободное время у выбранного доктора: " + doctorSchedule.getDoctorSchedule().get(selectedDoctor));
                    System.out.println("Выберите время для записи:");
                    String appointmentTime = scanner.nextLine();

                    if (doctorSchedule.isTimeAvailable(selectedDoctor, appointmentTime) && !appointments.containsValue(appointmentTime)) {
                        doctorSchedule.scheduleAppointment(selectedDoctor, appointmentTime);
                        appointments.put(userName, appointmentTime + " " + selectedDoctor.getName() + ", " + selectedDoctor.getOffice() + ", " + selectedDoctor.getSpeciality());
                    } else {
                        System.out.println("Это время уже занято или недоступно, выберите другое.");
                    }

                    break;

                case 2:
                    System.out.println("Записи на прием:");
                    for (Map.Entry<String, String> entry : appointments.entrySet()) {
                        System.out.println(entry.getKey() + " - " + entry.getValue());
                    }
                    break;

                case 3:
                    System.out.println("Программа закрыта");
                    break;

                default:
                    System.out.println("Неправильный выбор. Попробуйте еще раз.");
                    break;
            }
        } while (choice != 3);
    }
}